﻿namespace TowerDefense.Invaders
{
    public class BasicInvader : Invader
    {
        public BasicInvader(Path path) : base(path)
        {
        }
    }
}
