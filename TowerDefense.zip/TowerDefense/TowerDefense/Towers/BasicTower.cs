﻿using System;

namespace TowerDefense.Towers
{
    public class BasicTower : Tower
    {
        public BasicTower(MapLocation location) : base(location)
        {
        }
    }
}
